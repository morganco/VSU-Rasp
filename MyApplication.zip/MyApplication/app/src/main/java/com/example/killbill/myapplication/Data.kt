package com.example.killbill.myapplication

class SheduleData(Name:String,Group:String,Faculty:String, Data:List<Day>) {
    val name: String? = Name
    val faculty: String? = Faculty
    val group: String? = Group
    val week = Data
}

class Day(Data:List<PairData>,Date:String,DayName:String){
    val data = Data
    val date = Date
    val dayName = DayName
}

class PairData(Name: String,HallNumber:String,Teacher:String,Type:String){
    val name = Name
    val time:String? = null
    val hallNumber = HallNumber
    val teacher = Teacher
    val type = Type
}

class University{
    private val math:Array<String> = arrayOf("МАТФАК","1","2","12","41")
    private val filf:Array<String> = arrayOf("ФИЛФАК","21","2","51")
    private val fizf:Array<String> = arrayOf("ФИЗФАК","27","33","49")
    private val unidata:Array<Array<String>> = arrayOf(math,filf,fizf)
    fun getFaculties():List<String>{
        val v = mutableListOf<String>()
        for(i in 0 until unidata.size){
            v.add(unidata[i][0])
        }
        return v
    }
    fun getGroups(fac:String):List<String>{
        val v = mutableListOf<String>()
        for(i in 0 until unidata.size){
            if(unidata[i][0]==fac){
                for(j in 1 until unidata[i].size){
                    v.add(unidata[i][j])
                }
                break
            }
        }
        return v
    }

}

class Shedule(Data:List<Day>){
    val data = Data
}