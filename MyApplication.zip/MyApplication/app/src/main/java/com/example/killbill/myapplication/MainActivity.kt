package com.example.killbill.myapplication

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import com.example.killbill.myapplication.Adapters.*
import android.R.attr.data
import android.widget.*
import android.widget.Toast
import org.w3c.dom.Text
import android.content.DialogInterface
import java.time.Clock.tick
import android.support.v7.app.AlertDialog




class MainActivity : AppCompatActivity() {
    val data:University = University()
    var ShedulesData = mutableListOf<SheduleData>()
    override fun onCreate(savedInstanceState: Bundle?) {
        var pager: ScreenPager = ScreenPager(this)
        super.onCreate(savedInstanceState)
        elem(0)
        getShedulesScreen()
    }

    fun getShedulesScreen(){
        setContentView(R.layout.shedules_layout)
        val recyclerView = findViewById<RecyclerView>(R.id.shed_r)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = AdapterSheduleList(ShedulesData)
    }


    fun elem(a:Int){
        ShedulesData.add(SheduleData("ОЛОЛО ","24","МАТФАК",getData()))
    }

    fun onClickSheduleButton(view:View){
        setContentView(R.layout.faculty_list)
        val data:University = University()
        val faculty_adapter = ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, data.getFaculties())
        val adapter = ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arrayListOf())

        faculty_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        var spinner = findViewById<View>(R.id.faculty_spinner) as Spinner
        spinner.adapter = faculty_adapter
        spinner.setSelection(0)

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                val selectedItem = parent.getItemAtPosition(position).toString()
                adapter.clear()
                adapter.addAll(data.getGroups(selectedItem))
                spinner = findViewById<View>(R.id.group_spinner) as Spinner
                spinner.adapter = adapter
                spinner.setSelection(0)
            }
            override fun onNothingSelected(parent: AdapterView<*>) {
            }
        }

    }

    fun onClickNewSheduleButton(view:View){
        val name = findViewById<EditText>(R.id.new_shedule_name).text.toString()
        val group = findViewById<Spinner>(R.id.group_spinner).selectedItem.toString()
        val faculty = findViewById<Spinner>(R.id.faculty_spinner).selectedItem.toString()
        if(name!=""){
                for (i in 0 until ShedulesData.size){
                    if(name == ShedulesData[i].name){
                        Toast.makeText(baseContext,"Такое имя уже существует",Toast.LENGTH_SHORT).show()
                        return
                    }
                }
                ShedulesData.add(SheduleData(name,group,faculty,getData()))
                getShedulesScreen()
        }
        else{
            Toast.makeText(baseContext,"Вы ввели не все данные",Toast.LENGTH_SHORT).show()
        }
    }

    var back_pressed:Long = 0
    override fun onBackPressed() {
        if (back_pressed + 2000 > System.currentTimeMillis())
            super.onBackPressed()
        else {
            Toast.makeText(baseContext, "Нажмите еще раз, чтобы выйти",
                    Toast.LENGTH_SHORT).show()
            getShedulesScreen()
        }
        back_pressed = System.currentTimeMillis()
    }

    fun onClickDeleteButton(view: View){
        val text = view.findViewById<TextView>(R.id.delete_button).text
        for(i in 0 until ShedulesData.size) if(i.toString()==text.toString()){

            val alertDialog = AlertDialog.Builder(this@MainActivity)
            alertDialog.setTitle("Вы уверены, что хотите это удалить?")

            alertDialog.setIcon(R.drawable.index)

            alertDialog.setPositiveButton("ДА", DialogInterface.OnClickListener { dialog, which ->
                ShedulesData.removeAt(i)
                Toast.makeText(getApplicationContext(), "Удалено", Toast.LENGTH_SHORT).show()
                getShedulesScreen()
            })

            alertDialog.setNegativeButton("НЕТ", DialogInterface.OnClickListener { dialog, which ->
                Toast.makeText(getApplicationContext(), "Отмена", Toast.LENGTH_SHORT).show()
            })
            alertDialog.show()
        }
        getShedulesScreen()
    }

    fun onClickShedule(view: View){
        val text = view.findViewById<TextView>(R.id.delete_button).text.toString().toInt()
        val slider:ScreenPager = ScreenPager(baseContext)
            for (i in 0 until ShedulesData[text].week.size){
                val day = ShedulesData[text].week[i]
                setContentView(R.layout.day_shedule)
                val view:View = findViewById(R.id.Day_shedule)
                val recyclerView = view.findViewById<RecyclerView>(R.id.Day_list)
                findViewById<TextView>(R.id.day_data).text = day.date
                findViewById<TextView>(R.id.day_name).text = day.dayName
                recyclerView.layoutManager = LinearLayoutManager(this)
                recyclerView.adapter = AdapterPairs(ShedulesData[text].week[i].data)
                slider.addScreen(view)
            }
        setContentView(slider)
    }

}

fun setPair(Name:String,Teacher:String,Type:String,Hall:String):PairData {
    return PairData(Name,Hall,Teacher,Type)
}
fun setDay(Date:String,DAY:String,Data:List<PairData>):Day{
    return Day(Data,Date,DAY)
}

fun getData():List<Day>{
    val data = mutableListOf<Day>()
    val pairs1 = mutableListOf<PairData>()
    val pairs2 = mutableListOf<PairData>()
    val pairs3 = mutableListOf<PairData>()
    pairs1.add(PairData("ВОВ","517","Пастернак","лк"))
    pairs1.add(PairData("ВОВ","517","Пастернак","лк"))
    pairs1.add(PairData("ООТПиСП","306","Ермаченко","лк"))
    data.add(Day(pairs1,"21.05.2018","Понедельник"))
    //pairs.clear()
    pairs2.add(setPair("Начертательная геометрия","Подоксенов","пр","517"))
    pairs2.add(setPair("Политология","Вожгурова","пр","306"))
    pairs2.add(setPair("Теория графов","Мехович","лб", "526"))
    pairs2.add(setPair("ООТПиСП","Маевская","лб","219"))
    data.add(setDay("22.05.2018","Вторник",pairs2))
    //pairs3.clear()
    pairs3.add(setPair("Начертательная геометрия","Подоксенов","лб","517"))
    pairs3.add(setPair("Физра","преподаватель","пр","спортзал"))
    pairs3.add(setPair("ТВсБД","Маевская","лб", "313"))
    data.add(setDay("23.05.2018","Среда",pairs3))
    return data
}